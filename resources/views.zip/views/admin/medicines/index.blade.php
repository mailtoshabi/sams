@extends('admin.layouts.master')
@section('title', 'Medicines')

@section('content')
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Medicines</h3>
        <a href="{{ route('admin.medicines.create') }}" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Add Medicine
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    <form method="GET" action="{{ route('admin.medicines.index') }}" class="row g-2 mb-4">
        <div class="col-md-3">
            <input type="text" name="search" class="form-control" placeholder="Search by name"
                   value="{{ request('search') }}">
        </div>

        <div class="col-md-3">
            <select name="formulation_id" class="form-select">
                <option value="all">All Formulations</option>
                @foreach($formulations as $formulation)
                    <option value="{{ $formulation->id }}" {{ request('formulation_id') == $formulation->id ? 'selected' : '' }}>
                        {{ $formulation->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="col-md-3">
            <select name="status" class="form-select">
                <option value="all">All Status</option>
                <option value="published" {{ request('status') == 'published' ? 'selected' : '' }}>Published</option>
                <option value="draft" {{ request('status') == 'draft' ? 'selected' : '' }}>Draft</option>
            </select>
        </div>

        <div class="col-md-3">
            <button type="submit" class="btn btn-outline-primary">
                <i class="bi bi-search"></i> Filter
            </button>
            <a href="{{ route('admin.medicines.index') }}" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-repeat"></i> Reset
            </a>
        </div>
    </form>
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Formulation</th>
                    <th>Status</th>
                    <th>Titles</th>
                    <th>Updated</th>
                    <th class="text-center" width="150">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($medicines as $medicine)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>
                            <strong>{{ $medicine->name }}</strong><br>
                            <small class="text-muted">{{ $medicine->slug }}</small>
                        </td>
                        <td>{{ $medicine->medicineType?->name ?? 'No type assigned' }}</td>
                        <td>{{ $medicine->formulation?->name ?? 'No formulation assigned' }}</td>
                        <td>
                            <span class="badge bg-{{ $medicine->status === 'published' ? 'success' : 'secondary' }}">
                                {{ ucfirst($medicine->status) }}
                            </span>
                        </td>
                        <td>
                            @foreach($medicine->titles as $title)
                                <span class="badge bg-info text-dark">{{ $title->name }}</span>
                            @endforeach
                        </td>
                        <td>{{ $medicine->updated_at->diffForHumans() }}</td>
                        <td class="text-center">
                            <a href="{{ route('admin.medicines.show', $medicine->id) }}" class="btn btn-sm btn-info">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="{{ route('admin.medicines.edit', $medicine->id) }}" class="btn btn-sm btn-warning">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="{{ route('admin.medicines.destroy', $medicine->id) }}" method="POST" class="d-inline">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Delete this medicine?')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </td>

                    </tr>
                @empty
                    <tr><td colspan="8" class="text-center text-muted">No medicines found</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    {{ $medicines->links() }}
</div>
@endsection
