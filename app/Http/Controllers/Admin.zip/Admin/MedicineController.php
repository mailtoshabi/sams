<?php

namespace App\Http\Controllers\Admin;

use App\Http\Utilities\Utility;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Medicine;
use App\Models\MedicineType;
use App\Models\Formulation;
use App\Models\Title;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class MedicineController extends Controller
{
    /**
     * Display all medicines.
     */
    public function index(Request $request)
    {
        $query = Medicine::with(['titles', 'medicineType', 'formulation']);

        if ($request->filled('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                    ->orWhere('ayurveda_name', 'like', "%{$request->search}%");
            });
        }

        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        if ($request->filled('formulation_id') && $request->formulation_id !== 'all') {
            $query->where('formulation_id', $request->formulation_id);
        }

        $medicines = $query->oldest()->paginate(Utility::PAGINATE_COUNT)->appends($request->all());
        $formulations = Formulation::where('status', 'published')->oldest()->get();
        return view('admin.medicines.index', compact('medicines', 'formulations'));
    }

    /**
     * Show the form to create a new medicine.
     */
    public function create()
    {
        $medicine_types = MedicineType::where('status', 'published')->oldest()->get();
        $formulations = Formulation::where('status', 'published')->oldest()->get();
        $titles = Title::where('status', 'published')->where('type', 'medicine')->orderBy('order_number')->oldest()->get();
        return view('admin.medicines.create', compact('titles', 'medicine_types', 'formulations'));
    }

    /**
     * Store a newly created medicine.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'ayurveda_name' => 'required|string|max:255',
            'medicine_type_id' => 'required',
            'formulation_id' => 'nullable|exists:formulations,id',
            // 'description' => 'nullable|string',
            'status' => 'nullable|string|in:published,draft',
            'image' => 'nullable|image|max:2048',
        ]);

        $validated['slug'] = Str::slug($validated['name']);
        $validated['user_id'] = auth()->id() ?? 1;

        // Save medicine
        $medicine = Medicine::create($validated);

        // Handle pivot titles (only if heading provided)
        if ($request->has('titles')) {
            foreach ($request->titles as $titleId => $data) {
                // $heading = trim($data['heading'] ?? '');
                $description = trim($data['description'] ?? '');
                $image = $data['image'] ?? null;

                if ($description !== '') {
                    $imagePath = null;

                    if (isset($data['image']) && $data['image'] instanceof \Illuminate\Http\UploadedFile) {
                        $imagePath = $data['image']->store('medicines', 'public');
                    }

                    $medicine->titles()->attach($titleId, [
                        // 'heading' => $heading,
                        'description' => $description,
                        'image_path' => $imagePath,
                    ]);
                }
            }
        }

        return redirect()->route('admin.medicines.index')
            ->with('success', 'Medicine created successfully.');
    }

    /**
     * Show edit form.
     */
    public function edit(Medicine $medicine)
    {
        $titles = Title::where('status', 'published')->where('type', 'medicine')->orderBy('order_number')->oldest()->get();
        $medicine_types = MedicineType::where('status', 'published')->oldest()->get();
        $formulations = Formulation::where('status', 'published')->oldest()->get();
        $medicine->load(['titles', 'formulation']);
        return view('admin.medicines.edit', compact('medicine', 'titles', 'medicine_types', 'formulations'));
    }

    /**
     * Update the specified medicine.
     */
    public function update(Request $request, Medicine $medicine)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'ayurveda_name' => 'required|string|max:255',
            'medicine_type_id' => 'required',
            'formulation_id' => 'nullable|exists:formulations,id',
            // 'description' => 'nullable|string',
            'status' => 'nullable|string|in:published,draft',
            'image' => 'nullable|image|max:2048',
        ]);

        $validated['slug'] = Str::slug($validated['name']);

        if ($request->hasFile('image')) {
            if ($medicine->image_path) {
                Storage::disk('public')->delete($medicine->image_path);
            }
            $validated['image_path'] = $request->file('image')->store('medicines', 'public');
        }

        $medicine->update($validated);

        // Update pivot table
        $medicine->titles()->detach();

        if ($request->has('titles')) {
            foreach ($request->titles as $titleId => $data) {
                // $heading = trim($data['heading'] ?? '');
                $description = trim($data['description'] ?? '');
                $imagePath = null;

                if ($description !== '') {
                    if (isset($data['image']) && $data['image'] instanceof \Illuminate\Http\UploadedFile) {
                        $imagePath = $data['image']->store('medicines', 'public');
                    }

                    $medicine->titles()->attach($titleId, [
                        // 'heading' => $heading,
                        'description' => $description,
                        'image_path' => $imagePath,
                    ]);
                }
            }
        }

        return redirect()->route('admin.medicines.index')
            ->with('success', 'Medicine updated successfully.');
    }

    public function show(Medicine $medicine)
    {
        $medicine->load(['titles', 'user', 'medicineType', 'formulation']);
        return view('admin.medicines.show', compact('medicine'));
    }


    /**
     * Delete a medicine.
     */
    public function destroy(Medicine $medicine)
    {
        // Remove associated images
        if ($medicine->image_path) {
            Storage::disk('public')->delete($medicine->image_path);
        }

        foreach ($medicine->titles as $title) {
            if ($title->pivot->image_path) {
                Storage::disk('public')->delete($title->pivot->image_path);
            }
        }

        $medicine->titles()->detach();
        $medicine->delete();

        return back()->with('success', 'Medicine deleted successfully.');
    }
}
